import React, {useState, useEffect} from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import {Card, CardActionArea, CardMedia, ImageList, ImageListItem, ImageListItemBar} from '@mui/material'
import {useStylesMui} from "../../css/makeStyles"
import ControlPointIcon from '@mui/icons-material/ControlPoint';
import {enumData} from 'src/enumData/enumData';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import utc from 'dayjs/plugin/utc'
import ImagePopup from 'src/popup/ImagePopup';
import DetailRecevied from "./tab/DetailRecevied";
import {CLabel} from "@coreui/react";
import {ReceivedAPI} from "../../service/ReceivedReceipt/ReceivedReceipt";
import {convertDateToDDMMYYHHMM, convertDateToMMDDYYYYFromAPI, formatNumber, validateText, validateCompareTwoDate, validateDate, validateProductList, validateWeigth, validateNumber, randomId,validateReceiptImage} from "../../common/FuncCommon";
import dayjs from "dayjs";
import DialogDetail from "../../components/dialogDetail/DialogDetail";
import {toast} from "react-toastify";
import NumberReceivedReceiptConfirmPopup from "../../pages/receivedReceiptError/NumberReceivedReceiptConfirmPopup";
import { CDN_URL } from 'src/constant/constantURL';
import { Typography } from '@material-ui/core';
import ClearIcon from '@mui/icons-material/Clear';
import SignatureImages from './SignatureImages';
import DeleteImageConfirmPopup from './DeleteImageConfirmPopup';
import uuid from 'react-uuid';
import ReceiptStatus from './ReceiptStatus';
import CancelConfirmPopup from './CancelConfirmPopup';
import InputField from 'src/components/inputField/InputField';
import { contractAPI } from 'src/service/contract/contractAPI';
import {TruckAPI} from "../../service/truck/Truck";
import PermissionUtil from 'src/util/PermissionUtil';
import { menuRoleConstant, permissionActionConstant } from 'src/constant/menuRoleConstant';


dayjs.extend(utc)
const deliveryType = enumData.deliveryType

export default function OrderDetail(props) {
    const classes = useStylesMui();
    const [open, setOpen] = React.useState(false);
    const [openImage, setOpenImage] = React.useState(false);
    const [value, setValue] = React.useState('1');
    const [imageIndex, setImageIndex] = React.useState(0);
    const [loading, setLoading] = useState(false)
    const [productList, setProductList] = useState([
        // {name: 1, "number": 10, "note": "k co gi", "laundryForm": "laundry"},
      ])
    const [receivedData, setReceivedData] = useState({
        code: null,
        productType: null,
        customer: null,
        contract: null,
        receivedDate: null,
        deliveryDate: null,
        rewash: false,
        note: "",
        numberRoom: "",
        status: "",
        weight: null,
        bagNumber: "",
        deliveryBagNumber: 0,
        numberOfLooseBags: "",
        specialInstructionOfReceipts: [],
        receivedLinkDeliveries: [],
        flagError: false,
        numberOfCheckBags: "",
        fsNote: "",
        receiptImage:"",
        referenceCode:"",
    })
    const [deliveryLinks, setDeliveryLinks] = useState([]);
    const [totalWeight, setTotalWeight] = useState(0)
    const [weightTime, setWeightTime] = React.useState([]);
    const [productListOptions, setProductListOptions] = useState([])
    const [isOpenConfirmNumberReceivedReceiptError, setOpenConfirmNumberReceivedReceiptError] = useState(false)
    const [contentOfNumberReceivedReceiptError, setContentOfNumberReceivedReceiptError] = useState("")
    const [images, setImages] = useState([])
    const [imageFilesReceipt, setImageFilesReceipt] = useState([]);
    const [listImgReceipt, setListImgReceipt] = useState([]);
    const [chooseListImgReceipt1, setChooseListImgReceipt1] = React.useState(false);
    const [imgFiles, setImgFiles] = useState([])
    const [signatureCustomer, setSignatureCustomer] = useState(null)
    const [signatureStaff, setSignatureStaff] = useState(null)
    const [deletedImgs, setDeletedImgs] = useState([])
    const [deletedIImgsRecepit, setDeletedImgsRecepit] = useState([])
    const [isOpenDeletedImgConfirmPopup, setOpenDeletedImgConfirmPopup] = useState(false)
    const [receivedReceiptError, setReceivedReceiptError] = useState({
        productList: "",
        numberReceived: "", 
        weight: "",
        numberAfterProduction: "",
        receivedDate: "",
        weightTime: "",
        compareReceivedDateAndDeliveryDate: "",
        numberOfCheckBags: "",
        
    })
    const [checkValidateReceivedProduct, setCheckValidateReceivedProduct] = useState({
        weight: "",
        numberOfCheckBags: "",
        truck: "",
        driver: "",
    })
    const [numberOfWeighings, setNumberOfWeighings] = useState([])
    const [isOpenCancelReceiptConfirmPopup, setOpenCancelReceiptConfirmPopup] = useState(false)
    const [cancelReceivedReceiptContent, setCancelReceivedReceiptContent] = useState("")
    const [validCancelContent, setValidCancelContent] = useState({
        error: "",
    })
    const [validReceivedButton, setValidReceivedButton] = useState({
        receiptImage: "",
        productList: ""
    })
    const [isBagNumberError, setIsBagNumberError] = useState(false)
    const [prodcutItemFromContract, setProdcutItemFromContract] = useState([])

    useEffect(() => {
        if(props.selectedId){
            getReceivedReceiptById()
            getDeliveryLinksById()
        }
    }, [props.selectedId])

    useEffect(() => {
        let sum = 0
        for(let i=0; i<weightTime.length; i++){
            sum += weightTime[i].value
        }
        setTotalWeight(formatNumber(sum, 5, 2)) 
    }, [weightTime])
    
    useEffect(() => {
        if(receivedData.contract?.value){
            getContractById()
        }
    }, [receivedData])

    const getContractById = async () => {
        try {
            let result = await contractAPI.getContractById(receivedData?.contract.value)
            if(result?.status === 200){
                setProdcutItemFromContract(() => {
                  let newProducts = result?.data?.data?.contractProducts.filter(
                    (item) =>
                      receivedData?.productType === "ordinary_product"
                        ? item.productTypeValue === "ordinary_product"
                        : item.productTypeValue === "special_product"
                  );

                  console.log("newProducts", newProducts)
                  return newProducts;
                });
            }

        }catch (err){

        }
    }

    // const onOpenDeletedImgConfirmPopup = (e, img) => {
    //     setOpenDeletedImgConfirmPopup(!isOpenDeletedImgConfirmPopup)
    //     setDeletedImg(img)
    // }

    const onOpenCancelReceiptConfirmPopup = () => {
        setOpenCancelReceiptConfirmPopup(!isOpenCancelReceiptConfirmPopup)
    }

    const onOpenConfirmNumberReceivedReceiptError = () => {
        setOpenConfirmNumberReceivedReceiptError(!isOpenConfirmNumberReceivedReceiptError)
    }

    const getDeliveryLinksById = async () => {
        try{
            let result = await ReceivedAPI.getDeliveryLinksById(props.selectedId)
            if(result?.status === 200) {
                let data = result?.data.data.map(item => {
                    let status = deliveryType.find(type => type.value === item.status)?.label
                    if(status){
                        return {...item, status: status}
                    }
                })

                setDeliveryLinks(data)
            }
        } catch (err){

        }
        
    }

    const getReceivedReceiptById = async () => {
        try {
            setLoading(true)
            let result = await ReceivedAPI.getReceivedReceiptById(props.selectedId)
            if(result?.status === 200){
                let data = result?.data?.data
                let receivedDate = convertDateToMMDDYYYYFromAPI(data?.receivedDate, true)
                let deliveryDate = convertDateToMMDDYYYYFromAPI(data?.deliveryDate, true)
                data.code = {
                    value: data.code,
                    label: data.code
                }

                data.productType = data?.productType?.value
                data.customer = {
                    value: data?.customer?.id,
                    label: data?.customer?.fullName
                }

                if(data?.contract){
                    data.contract = {
                        value: data?.contract?.id,
                        label: data?.contract?.code
                    }
                }

                if (data?.truck) {
                    data.truck = {
                        value: data.truck?.id,
                        label: `${data.truck?.code}`,
                        driver: data.truck?.staff,
                    }
                }
                if (data?.driver) {
                    data.driver = {
                        value: data.driver?.id,
                        label: `${data.driver?.code} - ${data.driver?.fullName}`,
                        code: data.driver?.code,
                        name: data.driver?.fullName,
                    }
                }

                let specialInstruction = []
                for(let item of data?.specialInstructionOfReceipts){
                    specialInstruction.push(item?.specialInstruction?.value)
                }

                data.specialInstructionOfReceipts = specialInstruction
                data.receivedDate = receivedDate
                data.deliveryDate = deliveryDate
                //options của tên mặt hàng
                let options = data?.itemReceivedList?.map(item => ({
                    value: item.productItem.id,
                    label: `${item.productItem.name} (${item.productItem.pieceType.name})`
                }))
                //lấy data cho bảng
                let newProductList = data?.itemReceivedList?.map(item => ({
                    id: item.id, //dùng để so sánh khi mặt hàng thuộc hợp đồng
                    productItemId: item.productItem.id, //dùng để so sánh khi là phiếu giao liên kết
                    name: item.productItem.id,
                    numberReceived: item.numberReceived,
                    randomNumberCheck: item.randomNumberCheck,
                    note: item.note,
                    laundryForm: item.laundryForm ? item.laundryForm.value : item.laundryForm,
                    numberAfterProduction: item.numberAfterProduction,
                    deliveryReceiptId: item.deliveryReceipt?.id,
                    deliveryReceiptCode: item.deliveryReceipt?.code
                }))
                
                if(data?.receivedLinkDeliveries?.length > 0){
                    data.receivedLinkDeliveries = data?.receivedLinkDeliveries?.map(item => ({
                        value: item?.deliveryReceipt?.id,
                        label: item?.deliveryReceipt?.code
                    }))
                }
                data.deliveryIds = data?.receivedLinkDeliveries.map(item => item.value)
                // let weightTimeClone = [...weightTime]
                let weightTimeList = []
                if(data?.weight){
                    let weightTemp = data?.weight.split(",").map(Number)
                    weightTimeList = weightTemp.map((item, index) => ({
                        id: uuid(),
                        value: item
                    }))
                }else{
                    weightTimeList.push({id: uuid(), value: 0})
                }
                // let weightTimeResult = [...weightTimeClone, ...weightTimeList]
             
                //hình ảnh
                let newImgList = []
                if(data.imageReceipts.length > 0){
                    newImgList = data.imageReceipts.map(item => ({
                        id: item.id,
                        name: item.image,
                        title: item.image,
                        img: `${CDN_URL}/receipt/image/${item.image}`,
                        src: `${CDN_URL}/receipt/thumbnail/${item.image}`,
                        soureType: item.createdSourceType
                    }))
                }

                //chữ ký
                let signatureCustomer = null
                let signatureStaff = null
               
                if(Object.keys(data?.signatureCustomer || {}).length > 0 && data?.signatureCustomer){
                    signatureCustomer = {
                        time: data?.signatureCustomer.signature_time,
                        url: `${CDN_URL}/receipt/signature/${data?.signatureCustomer.signature_url}`
                    }
                }

                if(data?.signatureStaff && Object.keys(data?.signatureStaff || {}).length > 0){
                    signatureStaff = {
                        time: data?.signatureStaff.signature_time,
                        url: `${CDN_URL}/receipt/signature/${data?.signatureStaff.signature_url}`
                    }
                }

                //check when received receipt has error
                let isBagNumberError = false
                if(props.isReceivedReceiptError){
                    if(data.bagNumber !== data.numberOfCheckBags){
                        isBagNumberError = true
                    }
                }

                console.log("data", data)

                console.log("dđ", data.receiptImage?.split(","))
                
                setIsBagNumberError(isBagNumberError)
                setReceivedData(data)
                setProductListOptions(options)
                setProductList(newProductList)
                setWeightTime(weightTimeList)
                setImages(newImgList)
                setSignatureCustomer(signatureCustomer)
                setSignatureStaff(signatureStaff)
                setLoading(false)
                setListImgReceipt(
                    data.receiptImage ? data.receiptImage?.split(",") : []
                  );
            }
        }catch (err){
            setLoading(false)
        }finally{
            setLoading(false)
        }
    }

    const handleCloseImage = () => {
        setOpenImage(false);
    };
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const onChangeDate = (value, name) => {
        setReceivedData({
            ...receivedData,
            [name]: value
        })
    }

    const onChangeReceivedData = (e) => {
        let name = e.target.name
        let value = e.target.value

        if(name === "bagNumber" || name === "numberOfCheckBags"){
            if(value <= 0){
                value = 0
            }
        }

        setReceivedData({
            ...receivedData,
            [name]: value
        })
    }

    const changeWeightTime = (e, id) => {
        let weightList = [...weightTime]
        let index = weightList.findIndex(item => item.id === id)
        if(index !== -1){
            weightList[index].value = formatNumber(Number(e.target.value), 5, 2)
        }
        setWeightTime(weightList)
    }

    const onChangeDriver = (e, value) => {
        if (value instanceof Object) {
            setReceivedData({
                ...receivedData,
                driver: value,
            });
        } else  if (value == '') {
            setReceivedData({
                ...receivedData,
                driver: undefined
            })
        }
    };

    const onChangeTruck = (e, value) => {
        console.log("onChange Truck ", value)
        if (value instanceof Object) {

            let item = value.driver;
            let truckDriver = item?.id !== 0 ? {
                value: item.id,
                label: `${item.code} - ${item.fullName}`,
                code: item.code,
                name: item.fullName,
            } : undefined;
            let updateDriver = receivedData.driverId == null || receivedData.driverId == undefined || receivedData.driverId !== "";
            setReceivedData({
                ...receivedData,
                driver: updateDriver ? truckDriver : receivedData.driver,
                truck: value,
            });
        } else  if (value == '') {
            setReceivedData({
                ...receivedData,
                truck: undefined
            })
        }
    };

    useEffect(() => {
        setNumberOfWeighings(weightTime)    
    }, [weightTime])

    const validate = () => {
        let errProductList = validateProductList(productList, receivedData.status, receivedData.productType);
        let receivedDate = validateDate(receivedData.receivedDate, "Ngày nhận")
        let compareTwoDate = validateCompareTwoDate(receivedData.receivedDate, receivedData.deliveryDate, "Ngày nhận", "Ngày giao")
        let numberOfCheckBags = ""
        let weightTime = ""

        // if(receivedData.status === "STAFF_RECEIVED"){
        //     if(numberOfWeighings.length > 0){
        //         weightTime = validateWeigth(numberOfWeighings)
        //     }
        // }

        // if(receivedData.status === "STAFF_RECEIVED"){
        //     if(Number(receivedData.numberOfCheckBags) <= 0){
        //         numberOfCheckBags = validateText(receivedData.numberOfCheckBags, "Vui lòng nhập số bao kiểm")
        //     }
        // }

        setReceivedReceiptError({
            ...receivedReceiptError,
          productList: errProductList,
          receivedDate: receivedDate,
          weightTime: weightTime,
          compareReceivedDateAndDeliveryDate: compareTwoDate,
          numberOfCheckBags: numberOfCheckBags
        });

        if (errProductList || receivedDate || weightTime|| compareTwoDate || numberOfCheckBags) {
            return false;
        } 
        
        return true      
    }

    const validateWhenCheckEnoughReceivedProduct = () => {
        let receivedNumberError = validateProductList(productList, "WAITING_RANDOM_CHECK")
        let weigthError = validateWeigth(Number(receivedData.weight))

        if(receivedNumberError !== "" || weigthError !== ""){
            setReceivedReceiptError({
                ...receivedReceiptError,
                numberReceived: receivedNumberError,
                weight: weigthError,
            })
            return false;
        }else{
            setReceivedReceiptError({
                ...receivedReceiptError,
                numberReceived: receivedNumberError,
                weight: weigthError,
            })
            return true;
        }
    }

    const validateWhenPackingConfirm = () => {
        let error = validateProductList(productList, "WASHING")

        if(error !== ""){
            setReceivedReceiptError({
                ...receivedReceiptError,
                numberAfterProduction: error
            })
            return false
        }else{
            setReceivedReceiptError({
                ...receivedReceiptError,
                numberAfterProduction: error
            })
            return true
        }

    }

    const validateWhenReceivedProduct = () => {
        let errorWeight = validateWeigth(Number(receivedData.weight))
        let numberOfCheckBags = validateNumber(receivedData.numberOfCheckBags, "Số bao kiểm")
        let errorTruck = validateText(receivedData?.truck?.value, "Vui lòng chọn xe");
        let errorDriver = validateText(receivedData?.driver?.value, "Vui lòng chọn tài xế");

        setCheckValidateReceivedProduct({
            weight: errorWeight,
            numberOfCheckBags: numberOfCheckBags,
            truck: errorTruck,
            driver: errorDriver,
        })

        if(errorWeight !== "" || numberOfCheckBags !== "" || errorTruck !== "" || errorDriver !== ""){
            return false
        }

        return true
    }


    useEffect(() => {
        if(checkValidateReceivedProduct.weight){
            toast.error(checkValidateReceivedProduct.weight)
        }

        if(checkValidateReceivedProduct.numberOfCheckBags){
            toast.error(checkValidateReceivedProduct.numberOfCheckBags)
        }

        if(checkValidateReceivedProduct.truck){
            toast.error(checkValidateReceivedProduct.truck)
        }

        if(checkValidateReceivedProduct.driver){
            toast.error(checkValidateReceivedProduct.driver)
        }
    }, [checkValidateReceivedProduct])

    useEffect(() => {
        if (receivedReceiptError?.productList) {
          toast.error(receivedReceiptError?.productList);
        }

        if (receivedReceiptError?.weight) {
          toast.error(receivedReceiptError?.weight);
        }

        if (receivedReceiptError?.numberReceived) {
          toast.error(receivedReceiptError?.numberReceived);
        }

        if (receivedReceiptError?.numberAfterProduction) {
            toast.error(receivedReceiptError?.numberAfterProduction);
        }

        if (receivedReceiptError?.receivedDate) {
            toast.error(receivedReceiptError?.receivedDate);
        }

        if (receivedReceiptError?.weightTime) {
            toast.error(receivedReceiptError?.weightTime);
        }

        if (receivedReceiptError?.compareReceivedDateAndDeliveryDate) {
            toast.error(receivedReceiptError?.compareReceivedDateAndDeliveryDate);
        }

        if(receivedReceiptError?.numberOfCheckBags){
            toast.error(receivedReceiptError?.numberOfCheckBags);
        }

    }, [receivedReceiptError])


    const refreshReceivedReceiptList = () => {
        if(props.refreshPage){{
            props.refreshPage()
        }}
    }

    const refreshReceivedReceiptListError = () => {
        if(props.refreshPageError){
            props.refreshPageError()
        }
    }

    const handleSave = async () => {
        if(validate()){
            setLoading(true)
            try {
                let receivedDate = convertDateToDDMMYYHHMM(receivedData?.receivedDate)
                let deliveryDate = convertDateToDDMMYYHHMM(receivedData?.deliveryDate)
                
                let signatureCustomer = "{}"
                let signatureStaff = "{}"

                if(receivedData?.signatureStaff && Object.keys(receivedData?.signatureStaff || {}).length > 0){
                    signatureStaff = JSON.stringify(receivedData.signatureStaff)
                }

                if(receivedData?.signatureCustomer && Object.keys(receivedData?.signatureCustomer || {}).length > 0){
                    signatureCustomer = JSON.stringify(receivedData.signatureCustomer)
                }

                // let deliveryIds = receivedData?.receivedLinkDeliveries.map(item => (item.value))
                let newProductList = productList.map(item => ({
                    deliveryReceiptId: item.deliveryReceiptId,
                    id: item.id,
                    productItemId: item.name,
                    numberReceived: item.numberReceived,
                    laundryFormValue: item.laundryForm ? item.laundryForm : undefined,
                    note: item.note,
                    randomNumberCheck: item.randomNumberCheck,
                    numberAfterProduction: item.numberAfterProduction ? item.numberAfterProduction : undefined
                }))
    
                let weight = ""
                if(weightTime.length > 0){
                    weight = weightTime.map(item => item.value).join(",")
                }
                let imageReceiptString = ""
                console.log("ssss",listImgReceipt)
                if(listImgReceipt.length > 0){
                    listImgReceipt.map(item => imageReceiptString+=`${item},`)
                  }
    
                let payload = {
                    receivedDate: `${receivedDate}:00.000Z`,
                    deliveryDate: receivedData?.deliveryDate ? `${deliveryDate}:00.000Z` : undefined,
                    note: receivedData?.note,
                    numberRoom: receivedData?.numberRoom,
                    specialInstruction: receivedData?.specialInstructionOfReceipts,
                    // deliveryIds: deliveryIds?.length > 0 ? deliveryIds : [],
                    deliveryIds: receivedData.deliveryIds?.length > 0 ? receivedData.deliveryIds : [],
                    status: receivedData?.status,
                    images: [],
                    bagNumber: receivedData?.bagNumber,
                    weight: weight,
                    signatureCustomer: signatureCustomer,
                    signatureStaff: signatureStaff,
                    itemReceivedCreateRequests: newProductList,
                    driverId: receivedData?.driver?.value,
                    truckId: receivedData?.truck?.value,
                    numberOfLooseBags: receivedData?.numberOfLooseBags,
                    // receiptImage: receivedData?.receiptImage
                    receiptImage:imageReceiptString.slice(0,-1),
                    referenceCode:receivedData?.referenceCode,
                }

                if(receivedData.status === "STAFF_RECEIVED"){
                    payload.numberOfCheckBags = Number(receivedData.numberOfCheckBags)
                }

                let result = await ReceivedAPI.updateReceivedReceipt(props.selectedId, payload)
                if(result?.status === 200){
                    if(props.isReceivedReceiptError){
                        refreshReceivedReceiptListError()
                    }else{
                        if(imgFiles.length > 0){
                            let newImgList = await sendingImg()
                            // setImages(newImgList)
                        }

                        if(deletedImgs.length > 0){
                            await handleRemoveImages()
                        }
                        refreshReceivedReceiptList()
                    }

                    await getReceivedReceiptById()
                    setLoading(false)
                    toast.success("Cập nhật phiếu nhận thành công.")

                }else{
                    toast.error(result.data?.message)
                    setLoading(false)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }
        }
    }

    const validateCancelReceivedReceipt = () => {
        let validContent = validateText(cancelReceivedReceiptContent.trim(), "Vui lòng nhập nội dung hủy phiếu")
        setValidCancelContent({
            error: validContent
        })

        if(validContent){
            return false
        }else{
            return true
        }
    }

    const validateReceivedButton = () => {
        let errorReceiptImage = validateReceiptImage(receivedData?.receiptImage, "Vui lòng upload hóa đơn")
        let errorProductList = validateProductList(productList, "WAITING", "", "STAFF_RECEIVED")
        

        setValidReceivedButton({
            productList: errorProductList,
            receiptImage: errorReceiptImage
        })

        if(errorReceiptImage !== "" || errorProductList !== ""){
            return false
        }
            
        return true       
    }

    useEffect(() => {
        if(validCancelContent.error){
            toast.error(validCancelContent.error)
        }
    }, [validCancelContent])

    useEffect(() => {
        if(validReceivedButton.receiptImage){
            toast.error(validReceivedButton.receiptImage)
        }

        if(validReceivedButton.productList){
            toast.error(validReceivedButton.productList)
        }
    }, [validReceivedButton])

    const onCancelReceivedReceipt = async () => {
        if(validateCancelReceivedReceipt()){
            setLoading(true)
            try {
                let result = await ReceivedAPI.updateReceivedReceiptStatus(props.selectedId, {
                    status: "CANCEL",
                    cancelNote: cancelReceivedReceiptContent.trim()
                })
                if(result.status === 200){
                    toast.success("Hủy phiếu thành công")
                    if(props.isReceivedReceiptError){
                        refreshReceivedReceiptListError()
                    }else{
                        refreshReceivedReceiptList()
                    }
                    props.handleClose()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }finally {
                setLoading(false)
            }
        }
    }

    const onReceivedProduct = async () => {
        if(validateWhenReceivedProduct()){
            setLoading(true)
            try {
                let result = await ReceivedAPI.updateReceivedReceiptStatus(props.selectedId, {status: "WAITING_RANDOM_CHECK"})
                if(result.status === 200){
                    toast.success("Đã tiếp nhận hàng thành công")
                    refreshReceivedReceiptList()
                    props.handleClose()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }finally {
                setLoading(false)
            }
        }
    }

    const onReceived = async () => {
         if(validateReceivedButton()){
            setLoading(true)
            try {
                let result = await ReceivedAPI.updateReceivedReceiptStatus(props.selectedId, {status: "STAFF_RECEIVED"})
            
                if(result.status === 200){
                    toast.success("Đã tiếp nhận hàng thành công")
                    refreshReceivedReceiptList()
                    props.handleClose()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }finally {
                setLoading(false)
            }
        }
    }

    const onCheckEnoughReceivedProduct = async () => {
        if(validateWhenCheckEnoughReceivedProduct()){
            setLoading(true)
            try {
                let result = await ReceivedAPI.updateReceivedReceiptStatus(props.selectedId, {status: "WASHING"})
                if(result.status === 200){
                    toast.success("Đã đủ hàng.")
                    refreshReceivedReceiptList()
                    props.handleClose()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }finally {
                setLoading(false)
            }
        }
    }

    const onPackingConfirmation = async () => {
        if(validateWhenPackingConfirm()){
            setLoading(true)
            try {
                let result = await ReceivedAPI.updateReceivedReceiptStatus(props.selectedId, {status: "PACKING"})
                if(result.status === 200){
                    toast.success("Đã đóng gói thành công.")
                    refreshReceivedReceiptList()
                    props.handleClose()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                }
            }catch (err){
                toast.error(err)
                setLoading(false)
            }finally {
                setLoading(false)
            }
        }
    }

    const onChangeContentOfNumberReceivedReceiptError = (e) =>{
        setContentOfNumberReceivedReceiptError(e.target.value)
    }

    const onConfirmNumberOfReceived = async () => {
        setLoading(true)
        try {
            let result = await ReceivedAPI.confirmNumberReceiveError(props.selectedId, {
                note: contentOfNumberReceivedReceiptError
            })

            if(result.status === 200){
                toast.success("Xác nhận thành công!")
                onOpenConfirmNumberReceivedReceiptError()
                refreshReceivedReceiptListError()
                props.handleClose()
                setLoading(false)
            }else{
                toast.error(result.data?.message)
            }
        }catch (err){
            toast.error(err)
            setLoading(false)
        }finally {
            setLoading(false)
        }
    }

    const onRequestToCheckProduct = async () => {
        try {
            setLoading(true)
            let result = await ReceivedAPI.requestReCheck(props.selectedId)
            if(result.status === 200){
                toast.success("Yêu cầu kiểm tra thành công!")
                refreshReceivedReceiptList()
                props.handleClose()
                setLoading(false)
            }else{
                toast.error(result.data?.message)
            }
        }catch (err){
            toast.error(err)
            setLoading(false)
        }finally {
            setLoading(false)
        }
    }

    const onDebtClosing = async () => {
        try {
            setLoading(true)
            let result = await ReceivedAPI.debtClosing(props.selectedId)
            if(result.status === 200){
                toast.success("Chốt công nợ thành công!")
                refreshReceivedReceiptList()
                props.handleClose()
                setLoading(false)
            }else{
                toast.error(result.data?.message)
            }
        }catch (err){
            toast.error(err)
            setLoading(false)
        }finally {
            setLoading(false)
        }
    }

    const onRemoveImg = (e, img) => {
        let newDeletedImgs = [...deletedImgs]
        if(img.soureType !== "PORTAL"){
            toast.error("Không được xóa ảnh!")
            return
        }

        let newImages = images.filter(item => item.id !== img.id)
        if(!img.idLocal){
            newDeletedImgs.push(img.id)
        }
            
        let newImgFiles = imgFiles.filter(item => item.idLocal !== img.idLocal)         

        console.log("newImgFiles", newImgFiles)

        setImgFiles(newImgFiles)
        setDeletedImgs(newDeletedImgs)
        setImages(newImages)
    }

    const onRemoveImgReceipt = (e, img) => {
        
        // if(img.soureType !== "PORTAL"){
        //     toast.error("Không được xóa ảnh!")
        //     return
        // }

        let newImages = listImgReceipt.filter(item => item!== img)
    
        setListImgReceipt(newImages)
    }

    const handleRemoveImages = async () => {
        try {          
            if(deletedImgs.length > 0){
                setLoading(true)
                let result = await ReceivedAPI.deleteImages(receivedData?.id, {
                    createdSourceType: "PORTAL",
                    imageIds: deletedImgs.join(",")
                })
    
                if(result?.status === 200){
                    // const imgClone = [...images]
                    // const newImges = imgClone.filter(item => item.id !== deletedImg.id)
                    // toast.success("Xóa hình ảnh thành công!")
                    // setImages(newImges)
                    // onOpenDeletedImgConfirmPopup()
                    setLoading(false)
                }else{
                    toast.error(result.data?.message)
                    setLoading(false)
                }     
            } 
        } catch (error) {
            toast.error(error)
            setLoading(false)
        }
    }

    const onUploadImg = (e) => {
        let id = randomId()
        let newImgFiles = [...imgFiles]
        let newImages = [...images]
        for(let i = 0; i < e.target.files.length; i++){
            if(e.target.files[i].size > 5242880){
                toast.error("Vui lòng chọn hình ảnh có kích thước dưới 5MB")
                return
            }
            newImgFiles.push({file: e.target.files[i], idLocal: `${id}_${i}`})
            newImages.push({
                id: `${id}_${i}`,
                idLocal: `${id}_${i}`,
                soureType: "PORTAL",
                img: URL.createObjectURL(e.target.files[i]),
                src: URL.createObjectURL(e.target.files[i]),
            })
        }

        setImgFiles(newImgFiles)
        setImages(newImages)
        e.target.value = null
    }

    const onUploadImgReceipt = async (e) => {
        let id = randomId();
        let newImgFiles = [...imageFilesReceipt];
        let newImgs1 = [...listImgReceipt];
        for (let i = 0; i < e.target.files.length; i++) {
          if (e.target.files[i].size > 5242880) {
            toast.error("Vui lòng chọn hình ảnh có kích thước dưới 5MB");
            return;
          }
          newImgFiles.push({ file: e.target.files[i], idLocal: `${id}_${i}` });
        }
    
        // setListImgReceipt(newImgs1);
        setLoading(true);
    
        let newImgs = newImgFiles.map((item, index) => {
          let blob = item.file.slice(0, item.file.size, "image/png");
          return new File([blob], `${id}_${index}W.png`);
        });
    
        let formData = new FormData();
        newImgs.map((item) => formData.append("images", item));
        formData.append("createdSourceType", "PORTAL");
        
        let respone = await ReceivedAPI.uploadImageReceiptReceivedDetail(
          receivedData?.id,
          formData
        );
    
        if (respone.status === 200) {
          setListImgReceipt([...newImgs1, ...respone?.data?.data]);
          setReceivedData({
            ...receivedData,
            receiptImage: respone?.data?.data.join(","),
          });
          setLoading(false);
          setImageFilesReceipt([]);
        } else {
          setLoading(false);
          toast.error(respone.data?.message);
        }
    
        e.target.value = null;
      };

    // useEffect(() => {
    //     if(imgFiles.length > 0){
    //         sendingImg()
    //     }
    // }, [imgFiles])

    const sendingImg = async () => {
        try {
            setLoading(true)
            let date = convertDateToDDMMYYHHMM(new Date(), true)
            let newDate = date.replaceAll(":", "").replaceAll("-", "")
            let files = [...imgFiles]
            let newFiles = files.map((item, index) => {
                let blob = item.file.slice(0, item.file.size, "image/png")
                return new File([blob], `${receivedData?.code?.value}_${newDate}_${index+1}W.png`)
            })
            let formData = new FormData()
            newFiles.map(item => formData.append("images", item))

            for (var [key, value] of formData.entries()) {
                console.log("key", key); 
                console.log("value", value); 
            }

            formData.append("createdSourceType", "PORTAL");
            let result = await ReceivedAPI.uploadImages(receivedData?.id, formData)
            if(result.status === 200){
                let data = result?.data?.data
                let newImgList
                if(data?.imageReceipts?.length > 0){
                    newImgList = data.imageReceipts.map(item => ({
                        id: item.id,
                        name: item.image,
                        title: item.image,
                        img: `${CDN_URL}/receipt/image/${item.image}`,
                        src: `${CDN_URL}/receipt/thumbnail/${item.image}`,
                        soureType: item.createdSourceType
                    }))
                }
                // toast.success("Thêm hình ảnh thành công.")
                setLoading(false)
                // setImages(newImgList)
                setImgFiles([])

                return newImgList
            }else{
                toast.error(result.data?.message)
                setLoading(false)
            }
        } catch (error) {
            toast.error(error)
            setLoading(false)
        }
    }

    const checkDisplayRequestToCheckButton = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT , permissionActionConstant.REQUEST_RECHECK)){
            let isDisplay = false
            if(receivedData?.status === "" || props.isView){
                isDisplay = false
            }else{
                if((receivedData?.status === "WAITING" || receivedData?.status === "PACKING" || receivedData?.status === "CANCEL" || receivedData?.status === "DONE" || props.isView) && !receivedData.flagError){
                    isDisplay = false
                }else{
                    isDisplay = true
                }
            }

            if(receivedData.flagError){
                isDisplay = false
            }

            return isDisplay
        }
        
        return false
    }

    const conditionUpdateImg = () => {
        if(receivedData?.status === "CANCEL" || receivedData?.status === "DONE" || receivedData?.status === "PACKING" || props.isView){
            return false
        }
        return true
    }

    const onChangeCancelReceivedReceiptContent = (e) => {
        setCancelReceivedReceiptContent(e.target.value)
    }

    const checkPermissionCancelReceived = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.APPROVE)){
            if(receivedData?.status === "WAITING"  && !props.isView){
                return true
            }

            return false
        }

        return false
    }

    const checkPermissionReceived = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.WEIGHED)){
            if(receivedData?.status === "STAFF_RECEIVED" && !receivedData.flagError && !props.isView){
                return true
            }

            return false
        }

        return false
    }

    const checkPermissionReceivedStatus = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.STAFF_RECEIVED)){
            if(receivedData?.status === "WAITING"){
                return true
            }

            return false
        }

        return false
    }

    const checkPermissionToCheckEnough = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.ENOUGH_RECEIVED_PRODUCT)){
            if(receivedData?.status === "WAITING_RANDOM_CHECK" && !receivedData.flagError && !props.isView){
                return true
            }

            return false
        }

        return false
    }

    const checkPermissionToPackReceived = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.PACKING)){
            if(receivedData?.status === "WASHING" && !receivedData.flagError && !props.isView){
                return true
            }

            return false
        }

        return false
    }

    const checkPermissionDebtClosing = () => {
        // if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.DEBT_CLOSING)){
        //     if(receivedData?.hasDeliveryReceiptDone && receivedData?.status !== "DONE" && !receivedData.flagError && !props.isView){
        //         return true
        //     }

        //     return false
        // }

        return false
    }

    const checkPermissionToUpdateReceived = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.RECEIVED_RECEIPT, permissionActionConstant.EDIT)){
            // eco-799
            if (receivedData?.flagError && (receivedData?.status==="WAITING_RANDOM_CHECK"||receivedData?.status==="STAFF_RECEIVED" || receivedData?.status==="WASHING"|| receivedData?.status==="WAITING")) {
                return true
            }  //end eco-799
         else   if(receivedData?.status === "PACKING" || receivedData?.status === "CANCEL" || receivedData?.status === "DONE" || props.isReceivedReceiptError || receivedData.flagError || props.isView){
                return false
            }

            return true
        }

        return false
    }

    const checkPermissionCancelError = () => {
        if(PermissionUtil.checkPermissionAction(menuRoleConstant.ERROR_RECEIVED_RECEIPT, permissionActionConstant.APPROVE)){
            if((receivedData?.status === "WAITING" || receivedData?.status === "STAFF_RECEIVED" || receivedData?.status === "WAITING_RANDOM_CHECK") && !props.isView){
                return true
            }

            return false
        }

        return false
    }

    return (
      <DialogDetail
        maxWidth={"xl"}
        open={props.open}
        handleClose={props.handleClose}
        title={props.title}
        // isCancelReceivedReceipt={
        //   (receivedData?.status === "WAITING" ||
        //   receivedData?.status === "STAFF_RECEIVED" ||
        //   receivedData?.status === "WAITING_RANDOM_CHECK") && !props.isView
        //     ? true
        //     : false
        // }
        isCancelReceivedReceipt={props.isReceivedReceiptError ? checkPermissionCancelError() : checkPermissionCancelReceived()}
        isRequestToCheckProduct={checkDisplayRequestToCheckButton()}
        // isReceivedProduct={
        //   receivedData?.status === "STAFF_RECEIVED" && !receivedData.flagError && !props.isView
        //     ? true
        //     : false
        // }
        isReceivedProduct={checkPermissionReceived()}
        //isReceived={checkPermissionReceivedStatus()}
        //isReceived={receivedData?.status === "WAITING" ? true : false}
        isReceived={checkPermissionReceivedStatus()}
        isCheckEnoughReceivedProduct={checkPermissionToCheckEnough()}
        // isCheckEnoughReceivedProduct={
        //   receivedData?.status === "WAITING_RANDOM_CHECK" && !receivedData.flagError && !props.isView
        //     ? true
        //     : false
        // }
        // isPackingConfirmation={
        //   receivedData?.status === "WASHING" && !receivedData.flagError && !props.isView
        //     ? true
        //     : false
        // }
        isPackingConfirmation={checkPermissionToPackReceived()}
        // isDebtClosing={
        //   receivedData?.hasDeliveryReceiptDone && receivedData?.status !== "DONE" && !receivedData.flagError && !props.isView ? true : false
        // }
        isDebtClosing={checkPermissionDebtClosing()}
        onOpenCancelReceiptConfirmDialog={onOpenCancelReceiptConfirmPopup}
        onReceivedProduct={onReceivedProduct}
        onReceived={onReceived}
        onCheckEnoughReceivedProduct={onCheckEnoughReceivedProduct}
        onPackingConfirmation={onPackingConfirmation}
        onRequestToCheckProduct={onRequestToCheckProduct}
        onDebtClosing={onDebtClosing}
        onSave={handleSave}
        // isSave={
        //   receivedData?.status === "PACKING" ||
        //   receivedData?.status === "CANCEL" || receivedData?.status === "DONE" || props.isReceivedReceiptError || receivedData.flagError || props.isView
        //     ? false
        //     : true
        // }
        isSave={checkPermissionToUpdateReceived()}
        // isConfirmNumberReceivedReceiptError={receivedData?.flagError}
        onOpenConfirmNumberReceivedReceiptError={
          onOpenConfirmNumberReceivedReceiptError
        }
        loading={loading}
        isCancelReceivedWithMessage={true}
      >
        <div>
          {/* <TabContext value={value}> */}
          {/* <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <TabList
                onChange={handleChange}
                aria-label="lab API tabs example"
              >
                <Tab label="Thông tin" value="1" />
                <Tab label="Hình ảnh" value="2" />
                <Tab label="Xác nhận" value="3" />
              </TabList>
            </Box> */}
          {/* <TabPanel value="1"> */}
          {/* <Box mb={3}>
            <CLabel className="title">Trạng thái phiếu</CLabel>
            <ReceiptStatus status={receivedData.status}/>
          </Box> */}
          <div style={{ marginTop: -15 }}></div>
          <DetailRecevied
            productList={productList}
            setProductList={setProductList}
            receivedData={receivedData}
            deliveryLinks={deliveryLinks}
            onChangeDate={onChangeDate}
            onChangeReceivedData={onChangeReceivedData}
            changeWeightTime={changeWeightTime}
            weightTime={weightTime}
            setWeightTime={setWeightTime}
            totalWeight={totalWeight}
            productListOptions={productListOptions}
            setProductListOptions={setProductListOptions}
            isReceivedReceiptError={props.isReceivedReceiptError}
            isBagNumberError={isBagNumberError}
            isView={props.isView}
            prodcutItemFromContract={prodcutItemFromContract}
            onChangeTruck={onChangeTruck}
            onChangeDriver={onChangeDriver}
            getDeliveryLinksById={getDeliveryLinksById}
          />
          {/* </TabPanel> */}
          {/* <TabPanel value="2"> */}
          {receivedData?.fsNote ?
            <div className="margin-top-20">
                <CLabel className="title">Ghi chú từ NVHT</CLabel>
                <InputField 
                    value={receivedData?.fsNote}
                    multiline={true}
                    rows={3}
                    disabled={true}
                />
            </div> : <div />
          }

          <div className="mt-15">
            {(images.length === 0 && receivedData.flagError) || (images.length === 0 && receivedData?.status !== "WAITING") ? <CLabel></CLabel> : <CLabel className="title">Hình ảnh các sản phẩm</CLabel>}
            <div style={{ marginTop: "5px" }}>
              {(conditionUpdateImg() && !receivedData.flagError) && (
                <Button variant="outlined" component="label" size="small">
                  Tải ảnh lên
                  <input
                    hidden
                    accept="image/*"
                    multiple
                    type="file"
                    onChange={onUploadImg}
                  />
                </Button>
              )}
            </div>
            {/* <ImageList cols={8} rowHeight={150} style={{ marginTop: "15px" }}>
                {images.map((item, index) => (
                  <ImageListItem
                    key={item.img}
                    sx={{ height: "50", objectFit: "contain" }}
                  >
                    <img
                      src={`${item.src}`}
                      srcSet={`${item.src}`}
                      alt={item.title}
                      loading="lazy"
                      onClick={() => {
                        setOpenImage(true);
                        setImageIndex(index);
                      }}
                      style={{ height: "50", objectFit: "contain" }}
                    />
                    <ImageListItemBar
                      title={item.title}
                      subtitle={<span>{item.title}</span>}
                      position="below"
                    />
                  </ImageListItem>
                ))}
              </ImageList> */}
            <Box
              style={{ marginTop: "15px", display: "flex", flexWrap: "wrap" }}
            >
              {images.map((item, index) => (
                <div
                  key={item.img}
                  style={{
                    display: "inline",
                    marginRight: "15px",
                    position: "relative",
                    marginBottom: "15px",
                  }}
                >
                  <Card>
                    <CardActionArea
                      onClick={() => {
                        // setChooseListImgReceipt(true);
                        setChooseListImgReceipt1(false);
                        setOpenImage(true);
                        setImageIndex(index);
                      }}
                    >
                      <CardMedia
                        component="img"
                        height="90px"
                        image={item.src}
                        sx={{ objectFit: "contain" }}
                      />
                    </CardActionArea>
                  </Card>
                  {/* {(conditionUpdateImg() && !receivedData.flagError) && ( */}
                    <div
                      style={{
                        position: "absolute",
                        top: "-4px",
                        right: "-2px",
                        cursor: "pointer",
                      }}
                      //   onClick={(e) => onOpenDeletedImgConfirmPopup(e, item)}
                      onClick={(e) => onRemoveImg(e, item)}
                    >
                      <ClearIcon color="error" />
                    </div>
                  {/* )} */}
                </div>
              ))}
            </Box>
          </div>

          {/* {receivedData?.status === "WAITING" ? (
          <> */}
            <div className="mt-15">
           <CLabel className="title">Hóa đơn</CLabel>
            <div style={{ marginTop: "5px" }}>
              {(conditionUpdateImg() && !receivedData.flagError) && ( 
                receivedData?.status === "WAITING" ?
                <Button variant="outlined" component="label" size="small">
                  Tải ảnh lên
                  <input
                    hidden
                    accept="image/*"
                    multiple
                    type="file"
                    onChange={onUploadImgReceipt}
                  />
                </Button>
               : "")}
            </div>
            <Box
              style={{ marginTop: "15px", display: "flex", flexWrap: "wrap" }}
            >
              {listImgReceipt.map((item, index) => (
                <div
                  key={item.img}
                  style={{
                    display: "inline",
                    marginRight: "15px",
                    position: "relative",
                    marginBottom: "15px",
                  }}
                >
                  <Card>
                    <CardActionArea
                      onClick={() => {
                        setChooseListImgReceipt1(true);
                        setOpenImage(true);
                        setImageIndex(index);
                      }}
                    >{console.log(item)}
                      <CardMedia
                        component="img"
                        height="90px"
                        image={`${
                            CDN_URL +
                            `/receipt/receivedBill/thumbnail/` +
                            item
                          }`}
                        sx={{ objectFit: "contain" }}
                      />
                    </CardActionArea>
                  </Card>
                  {(conditionUpdateImg() && !receivedData.flagError) && (
                    <div
                      style={{
                        position: "absolute",
                        top: "-4px",
                        right: "-2px",
                        cursor: "pointer",
                      }}
                      //   onClick={(e) => onOpenDeletedImgConfirmPopup(e, item)}
                      onClick={(e) => onRemoveImgReceipt(e, item)}
                    >
                        {receivedData?.status === "STAFF_RECEIVED" ? "": <ClearIcon color="error" />}
                      
                    </div>
                  )}
                </div>
              ))}
            </Box>
          </div>
          {/* </>
        ) : (
          ""
        )} */}

          {/* </TabPanel> */}
          {/* <TabPanel value="3"> */}
          {((signatureCustomer !== null && Object.keys(signatureCustomer || {}).length > 0) || (signatureStaff !== null && Object.keys(signatureStaff || {}).length > 0)) && ( 
              <SignatureImages
                signatureCustomer={signatureCustomer}
                signatureStaff={signatureStaff}
              />
            )} 
          {/* </TabPanel>
          </TabContext> */}
        </div>

        <div>
          <ImagePopup
            open={openImage}
            images={chooseListImgReceipt1 ? listImgReceipt : images}
            //images={images}
            handleClose={handleCloseImage}
            imageIndex={imageIndex}
            chooseListImgReceipt1={chooseListImgReceipt1}
          />
        </div>

        {isOpenConfirmNumberReceivedReceiptError && (
          <NumberReceivedReceiptConfirmPopup
            open={isOpenConfirmNumberReceivedReceiptError}
            handleClose={onOpenConfirmNumberReceivedReceiptError}
            content={contentOfNumberReceivedReceiptError}
            onChangeContent={onChangeContentOfNumberReceivedReceiptError}
            onConfirm={onConfirmNumberOfReceived}
            loading={loading}
          />
        )}

        {isOpenCancelReceiptConfirmPopup && (
            <CancelConfirmPopup 
                open={isOpenCancelReceiptConfirmPopup}
                handleClose={onOpenCancelReceiptConfirmPopup}
                content={cancelReceivedReceiptContent}
                onChangeContent={onChangeCancelReceivedReceiptContent}
                onConfirm={onCancelReceivedReceipt}
                loading={loading}
            />
        )}

        {/* {isOpenDeletedImgConfirmPopup && (
          <DeleteImageConfirmPopup
            open={isOpenDeletedImgConfirmPopup}
            handleCloseConfirm={onOpenDeletedImgConfirmPopup}
            onSave={removeImage}
            loading={loading}
          />
        )} */}
      </DialogDetail>
    );
}
import { CButton, CImg } from "@coreui/react";
import React, {
  useLayoutEffect,
  useRef,
  useState,
  useEffect,
  Component,
} from "react";
import {
  DataSheetGrid,
  keyColumn,
  Column,
  textColumn,
  intColumn,
  DynamicDataSheetGrid,
} from "react-datasheet-grid";
import Select, { GroupBase, SelectInstance } from "react-select";
import { enumData } from "src/enumData/enumData";
import DeleteRow from "../../components/dataSheet/deleteRow/DeleteRow";

export default class OrderSheetRecevied extends Component {
  constructor(props) {
    super(props);
    this.SelectComponent = React.memo(
      ({
        active,
        rowData,
        setRowData,
        focus,
        stopEditing,
        columnData,
        rowIndex,
      }) => {
        var _a;
        const ref = useRef(null);
        useLayoutEffect(() => {
          var _a, _b;
          if (focus) {
            // (_a = ref.current) === null || _a === void 0 ? void 0 : _a.focus();
            ref.current?.focus();
          } else {
            // (_b = ref.current) === null || _b === void 0 ? void 0 : _b.blur();
            ref.current?.blur();
          }
        }, [focus]);
        return React.createElement(Select, {
          ref: ref,
          styles: {
            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
            container: (provided) =>
              Object.assign(Object.assign({}, provided), {
                flex: 1,
                alignSelf: "stretch",
                pointerEvents: focus ? undefined : "none",
              }),
            control: (provided) =>
              Object.assign(Object.assign({}, provided), {
                height: "100%",
                border: "none",
                boxShadow: "none",
                background: "none",
              }),
            indicatorSeparator: (provided) =>
              Object.assign(Object.assign({}, provided), { opacity: 0 }),
            indicatorsContainer: (provided) =>
              Object.assign(Object.assign({}, provided), {
                opacity: active ? 1 : 0,
              }),
            placeholder: (provided) =>
              Object.assign(Object.assign({}, provided), {
                opacity: active ? 1 : 0,
              }),
          },
          className: "dsg-input",
          isDisabled: columnData.disabled,
          value:
            (_a = columnData.data.find(
              ({ value }) =>
                value ===
                (columnData.type == "name" ? rowData.name : rowData.laundryForm)
            )) !== null && _a !== void 0
              ? _a
              : null,
          menuPortalTarget: document.body,
          menuIsOpen: focus,
          onChange: (value) => {
            console.log(rowData);
            console.log(value);
            console.log(rowIndex);
            // if (value === null)
            //     return;
            // setRowData(value.value);

            let nData = [...this.props.productList];
            {
              columnData.type == "name"
                ? (nData[rowIndex].name = value.value)
                : (nData[rowIndex].laundryForm = value.value);
            }

            this.props.setProductLIst([...nData]);

            setTimeout(stopEditing, 0);
          },
          onMenuClose: () => stopEditing({ nextRow: false }),
          options: columnData.data,
        });
      }
    );
    this.selectColumn = (options, type) => ({
      component: this.SelectComponent,
      columnData: options,
      disableKeys: true,
      keepFocus: true,
      disabled: options.disabled,
      type: type,
      deleteValue: () => null,
      // copyValue: ({rowData}) => {var _a, _b; return (_b = (_a = options.choices.find((choice) => choice.value === rowData)) === null || _a === void 0 ? void 0 : _a.label) !== null && _b !== void 0 ? _b : null;},
      // pasteValue: ({value}) => {var _a, _b; return (_b = (_a = options.choices.find((choice) => choice.label === value)) === null || _a === void 0 ? void 0 : _a.value) !== null && _b !== void 0 ? _b : null;},
    });
  }
  checkLaundryForm() {
    if (
      this.props.receivedData?.flagError ||
      this.props.receivedData?.status === "DONE"
    ) {
      if (
        this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
        this.props.receivedData?.status === "STAFF_RECEIVED" ||
        this.props.receivedData?.status === "WASHING" ||
        this.props.receivedData?.status === "WAITING"
      ) {
        return false;
      }
      return true;
    }
    return false;
  }
  render() {
    //hàng thường
    const columns1 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              keyColumn: "name",
              minWidth: 300,
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData?.status === "DONE"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData?.status === "DONE" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData?.status === "DONE"
                ? true
                : false,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData?.status === "DONE" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];

    //hàng đặc biệt
    const columns2 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData?.status === "DONE"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData?.status === "DONE" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData?.status === "DONE"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData?.status === "DONE" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng thường với status đang giặt
    const columns3 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng đăc biệt với status đang giặt
    const columns4 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng thường với mặt hàng liên kết
    const columns5 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng đặc biệt với mặt hàng liên kết
    const columns6 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng thường với mặt hàng liên kết với status đang giặt
    const columns7 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];
    //hàng đặc biệt với mặt hàng liên kết với status đang giặt
    const columns8 =
      this.props.receivedData.status !== "STAFF_RECEIVED"
        ? [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            {
              ...keyColumn("randomNumberCheck", intColumn),
              title: "Số lượng kiểm tra tại nhà máy",
              disabled:
                (this.props.receivedData.status === "STAFF_RECEIVED" ||
                  // this.props.receivedData.status === "WASHING" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK") &&
                !this.props.receivedData.flagError
                  ? false
                  : true,
            },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              minWidth: 200,
              keyColumn: "laundryForm",
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ]
        : [
            {
              ...this.selectColumn({
                data: this.props.productListOptions,
                type: "name",
              }),
              title: "Tên mặt hàng",
              minWidth: 300,
              keyColumn: "name",
              disabled: true,
            },
            {
              ...keyColumn("deliveryReceiptCode", textColumn),
              title: "Phiếu liên kết",
              disabled: true,
            },
            {
              ...keyColumn("numberReceived", intColumn),
              title: "Số lượng nhận",
              disabled: this.props.receivedData?.flagError
                ? this.props.receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData?.status === "STAFF_RECEIVED" ||
                  this.props.receivedData?.status === "WASHING" ||
                  this.props.receivedData?.status === "WAITING"
                  ? false
                  : true
                : this.props.receivedData.status === "STAFF_RECEIVED" ||
                  this.props.receivedData.status === "WAITING_RANDOM_CHECK" ||
                  this.props.receivedData.status === "WASHING"
                ? true
                : false,
            },
            // {
            //     ...keyColumn('randomNumberCheck', intColumn),
            //     title: 'Số lượng kiểm tra tại nhà máy',
            //     disabled: (this.props.receivedData.status === "STAFF_RECEIVED" || this.props.receivedData.status === "WASHING" || this.props.receivedData.status === "WAITING_RANDOM_CHECK") && !this.props.receivedData.flagError ? false : true
            // },
            {
              ...keyColumn("numberAfterProduction", intColumn),
              title: "Số lượng sau sx",
              disabled:
                this.props.receivedData.status !== "WASHING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
            {
              ...this.selectColumn({
                data: this.props.laundryFormOptions,
                type: "laundryForm",
              }),
              title: "Hình thức giặt ủi",
              keyColumn: "laundryForm",
              minWidth: 200,
              disabled: this.checkLaundryForm()
            },
            {
              ...keyColumn("note", textColumn),
              title: "Mô tả đồ khách",
              minWidth: 150,
              disabled:
                this.props.receivedData?.status === "PACKING" ||
                this.props.receivedData.flagError
                  ? true
                  : false,
            },
          ];

    const productType = this.props.receivedData.productType;
    const isWashing =
      this.props.receivedData.status === "WASHING" ||
      this.props.receivedData.status === "PACKING" ||
      this.props.receivedData.status === "DONE"
        ? true
        : false;
    const isDeliveryReceipt =
      this.props.receivedData.receivedLinkDeliveries.length > 0 ? true : false;

    return (
      <DynamicDataSheetGrid
        height="100%"
        disableContextMenu
        disableExpandSelection
        value={this.props.productList}
        onChange={(value) => {
          console.log("Value", value);
          for (let i = 0; i < value.length; i++) {
            if (value[i]?.numberReceived < 0) {
              value[i].numberReceived = 0;
            }

            if (value[i]?.numberAfterProduction < 0) {
              value[i].numberAfterProduction = 0;
            }

            if (value[i]?.randomNumberCheck < 0) {
              value[i].randomNumberCheck = 0;
            }
          }
          let index = value.findIndex((item) => item === null);
          if (index === -1) {
            this.props.setProductList(value);
          }
        }}
        columns={
          productType === "ordinary_product" && isDeliveryReceipt && isWashing
            ? columns7
            : productType === "special_product" &&
              isDeliveryReceipt &&
              isWashing
            ? columns8
            : productType === "ordinary_product" && isDeliveryReceipt
            ? columns5
            : productType === "special_product" && isDeliveryReceipt
            ? columns6
            : productType === "ordinary_product" && isWashing
            ? columns3
            : productType === "special_product" && isWashing
            ? columns4
            : productType === "ordinary_product"
            ? columns1
            : columns2
        }
        addRowsComponent={false}
        stickyRightColumn={
          this.props.receivedData.status === "WAITING" &&
          !this.props.receivedData.flagError &&
          !this.props.isView
            ? {
                component: ({ rowIndex, deleteRow }) => (
                  <DeleteRow deleteRow={deleteRow} rowIndex={rowIndex} />
                ),
              }
            : null
        }
        cellClassName={({ rowData, rowIndex, columnId }) => {
          if (!this.props.isBagNumberError) {
            if (
              this.props.isReceivedReceiptError &&
              rowData.numberReceived !== rowData.randomNumberCheck
            ) {
              if (
                columnId === "numberReceived" ||
                columnId === "randomNumberCheck"
              ) {
                return "cell-error";
              }
            }
          }
        }}
      />
    );
  }
}

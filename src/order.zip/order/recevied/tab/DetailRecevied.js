import React, { useState, useEffect } from "react";
import { CCol, CRow, CLabel } from "@coreui/react";
import {
  FormControlLabel,
  Checkbox,
  Alert,
  Box,
  Tooltip,
  Link,
} from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";
import { enumData } from "src/enumData/enumData";
import { useStylesMui } from "src/css/makeStyles";
import uuid from "react-uuid";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import AutoSuggest from "../../../components/autoSuggest/AutoSuggest";
import InputField from "../../../components/inputField/InputField";
import OrderSheetRecevied from "../OrderSheetRecevied";
import MultiSelect from "../../../components/multiSelect/MultiSelect";
import InputDateTimePicker from "../../../components/datetimePicker/InputDateTimePicker";
import SelectComponent from "../../../components/selectBox/SelectComponent";
import NormalButton from "../../../components/normalButton/Button";
import ProductListPopup from "../../../pages/contracts/detail/ProductListPopup";
import "../../../css/custom.css";
import DeliveryReceiptProductListPopup from "../DeliveryReceiptProductListPopup";
import { StaffAPI } from "../../../service/staff/Staff";
import { TruckAPI } from "../../../service/truck/Truck";
import { useEnumData } from "src/hooks/useEnumData";
import { default as DeliveryPopup } from "../../delivery/OrderDetail";
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@material-ui/core";
import {
  StyledTableCell,
  StyledTableRow,
  useStylesTableMUI,
} from "src/css/stylesCellTableMUI";

export default function DetailRecevied({
  productList,
  setProductList,
  receivedData,
  deliveryLinks,
  onChangeDate,
  onChangeReceivedData,
  changeWeightTime,
  weightTime,
  setWeightTime,
  totalWeight,
  productListOptions,
  setProductListOptions,
  isReceivedReceiptError,
  isBagNumberError,
  isView,
  prodcutItemFromContract,
  onChangeTruck,
  onChangeDriver,
  getDeliveryLinksById,
}) {
  const classes = useStylesMui();
  const classesTable = useStylesTableMUI();
  const { productTypes, specialInstructions, laundryForms } = useEnumData();
  const [rewash, setRewash] = React.useState(false);
  const [receivedLinkDeliveries, setReceivedLinkDeliveries] = useState(null);
  const [isOpenProductListPopup, setOpenProductListPopup] = useState(false);
  const [isOpenLinkTicketProductPopup, setOpenLinkTicketProductPopup] =
    useState(false);
  const [drivers, setDrivers] = useState([]);
  const [driver, setDriver] = useState(null);
  const [trucks, setTrucks] = useState([]);
  const [truck, setTruck] = useState(null);
  const [isOpenDeliveryPopup, setOpenDeliveryPopup] = useState(false);
  const [deliveryId, setdeliveryId] = useState("");

  const onOpenProductPopup = () => {
    setOpenProductListPopup(!isOpenProductListPopup);
  };

  const handleChangeRewash = () => {
    setRewash(!rewash);
  };

  const onOpenAndCloseDeliveryPopup = (deliveryId) => {
    getDeliveryLinksById();
    setOpenDeliveryPopup(!isOpenDeliveryPopup);
    setdeliveryId(deliveryId);
  };

  useEffect(() => {
    if (receivedData?.receivedLinkDeliveries?.length > 0) {
      let temp = receivedData?.receivedLinkDeliveries.map((item) => item.label);
      // let result = temp.join(", ")
      setReceivedLinkDeliveries(temp);
    }
    setTruck(receivedData.truck);
    setDriver(receivedData.driver);
  }, [receivedData]);

  useEffect(() => {
    getAllTruck();
    getAllDriver();
  }, []);

  const getAllDriver = async () => {
    try {
      let result = await StaffAPI.getAllStaff1({
        page: 0,
        size: 20,
        role: "DRIVER",
        status: "ACTIVE",
      });
      console.log(result);
      if (result.status === 200) {
        let temp = result?.data.data.map((item) => ({
          value: item.id,
          label: `${item.code} - ${item.fullName}`,
          code: item.code,
          name: item.fullName,
        }));

        setDrivers(temp);
        console.log("drivers", temp);
      }
    } catch (err) {}
  };

  const getAllTruck = async () => {
    try {
      // let result = await TruckAPI.getAllTruck(2000, 0,"ACTIVE");
      let result = await TruckAPI.getAllTruck1({
        page: 0,
        size: 2000,
        status: "ACTIVE",
      });

      console.log(result);
      if (result.status === 200) {
        let temp = result?.data.data.map((item) => ({
          value: item.id,
          label: `${item.code}`,
          driver: item.staff,
        }));

        setTrucks(temp);
        console.log("all truck", temp);
      }
    } catch (err) {}
  };

  const onChangeProductList = (data) => {
    console.log("data", data);
    let newData = [];
    let options = [...productListOptions];
    let productListClone = [...productList];
    if (data.length > 0) {
      data.map((item) =>
        newData.push({
          name: item.id,
          numberReceived: 0,
          randomNumberCheck: 0,
          note: item.note,
          laundryForm: "",
          numberAfterProduction: 0,
        })
      );

      for (let i = 0; i < data.length; i++) {
        let index = options.findIndex((item) => item.value === data[i].id);
        if (index === -1) {
          options.push({
            value: data[i].id,
            label: `${data[i].name} (${data[i].pieceTypeName})`,
          });
        }
        // selectedOptions.push({
        //     value: data[i].id,
        //     label: `${data[i].name} (${data[i].pieceTypeName})`
        // })
      }

      setProductList([...productListClone, ...newData]);
      setProductListOptions(options);
    }
  };

  const onOpenLinkTicketProductPopup = () => {
    setOpenLinkTicketProductPopup(!isOpenLinkTicketProductPopup);
  };

  const onGetProductListFromPopup = (data) => {
    console.log({ data });
    let productListClone = [...productList];
    let options = [...productListOptions];
    if (data.length > 0) {
      let productListResult = [...productListClone, ...data];
      for (let i = 0; i < data.length; i++) {
        let index = options.findIndex((item) => item.value === data[i].id);
        if (index === -1) {
          options.push({
            value: data[i].id,
            label: `${data[i].name} (${data[i].pieceTypeName})`,
          });
        }
      }
      setProductList(productListResult);
      setProductListOptions(options);
    }
  };

  const onRemoveWeight = (e, weight) => {
    let weightTimeClone = [...weightTime];
    let result = weightTimeClone.filter((item) => item.id !== weight.id);
    setWeightTime(result);
  };

  const checkDisableRoomNumber = () => {
    if (
      receivedData?.status === "PACKING" ||
      receivedData?.status === "STAFF_RECEIVED" ||
      receivedData?.status === "WAITING_RANDOM_CHECK" ||
      receivedData?.status === "WASHING" ||
      receivedData?.status === "DONE" ||
      receivedData?.flagError ||
      isView
    ) {
      return true;
    }
    return false;
  };

  const checkDisableBagNumber = () => {
    let otherStatus =
      receivedData.status !== "STAFF_RECEIVED" ||
      receivedData?.status === "STAFF_RECEIVED" ||
      receivedData?.status === "DONE";
    if (!receivedData.flagError) {
      if ((otherStatus && receivedData.status !== "WAITING") || isView) {
        return true;
      }
    }
    return false;
  };

  const checkDisableReceivedDate = () => {
    if (
      receivedData?.status === "PACKING" ||
      receivedData?.status === "STAFF_RECEIVED" ||
      receivedData?.status === "WAITING_RANDOM_CHECK" ||
      receivedData?.status === "WASHING" ||
      receivedData?.status === "DONE" ||
      receivedData?.flagError ||
      isView
    ) {
      return true;
    }
    return false;
  };

  return (
    <div>
      <CLabel className="title">Thông tin chung</CLabel>
      {receivedData.flagError && (
        <Box mb={2}>
          <Alert severity="error">
            Số lượng kiểm đếm tại nhà máy đang không khớp với số lượng nhận. Vui
            lòng kiểm tra lại thông tin.
          </Alert>
        </Box>
      )}
      <CRow>
        <CCol>
          <AutoSuggest
            options={[]}
            label="Mã phiếu"
            disabled={true}
            value={receivedData?.code}
          />
        </CCol>
        <CCol>
          <SelectComponent
            label={"Loại hàng"}
            name="productType"
            value={receivedData?.productType}
            options={productTypes}
            disabled={true}
          />
        </CCol>
        <CCol>
          <AutoSuggest
            options={[]}
            label="Khách hàng"
            disabled={true}
            value={receivedData?.customer}
          />
        </CCol>
        <CCol>
          <MultiSelect
            options={specialInstructions}
            label="Yêu cầu"
            onChange={onChangeReceivedData}
            name="specialInstructionOfReceipts"
            value={receivedData?.specialInstructionOfReceipts}
            disabled={
              receivedData?.status === "PACKING" ||
              receivedData?.status === "DONE" ||
              receivedData?.status === "STAFF_RECEIVED" ||
              receivedData?.status === "WAITING_RANDOM_CHECK" ||
              receivedData?.status === "WASHING" ||
              receivedData?.flagError ||
              isView
                ? true
                : false
            }
          />
        </CCol>
      </CRow>
      <CRow className="mt-15">
        <CCol xs={1}>
          <FormControlLabel
            className={classes.root}
            control={
              <Checkbox
                checked={receivedData?.rewash}
                onChange={handleChangeRewash}
                disabled={true}
              />
            }
            label="Rewash"
          />
        </CCol>
        <CCol xs={2}>
          <InputField
            label="Số bao rời"
            onChange={onChangeReceivedData}
            value={receivedData?.numberOfLooseBags}
            name="numberOfLooseBags"
          />
        </CCol>
        <CCol style={{ display: "flex", gap: 1 }}>
          <InputField
            type="number"
            label="Số bao nhận"
            onChange={onChangeReceivedData}
            value={receivedData?.bagNumber}
            name="bagNumber"
            disabled={checkDisableBagNumber()}
            error={isBagNumberError}
            InputProps={{
              /* //eco-799  */
              readOnly: receivedData?.flagError
                ? receivedData?.status === "WAITING_RANDOM_CHECK" ||
                  receivedData?.status === "STAFF_RECEIVED" ||
                  receivedData?.status === "WASHING" ||
                  receivedData?.status === "WAITING"
                  ? false
                  : true
                : false,
            }}
          />

          {receivedData?.status !== "WAITING" && (
            <InputField
              type="number"
              label="Số bao kiểm"
              onChange={onChangeReceivedData}
              value={receivedData?.numberOfCheckBags}
              name="numberOfCheckBags"
              disabled={
                receivedData?.status !== "STAFF_RECEIVED" &&
                !receivedData.flagError
              }
              error={isBagNumberError}
              InputProps={{
                readOnly: receivedData?.flagError || isView ? true : false,
              }}
            />
          )}
        </CCol>
        <CCol>
          <InputDateTimePicker
            label="Ngày nhận"
            value={receivedData.receivedDate}
            onChange={(value) => onChangeDate(value, "receivedDate")}
            disabled={checkDisableReceivedDate()}
          />
        </CCol>
        <CCol>
          <InputDateTimePicker
            label="Ngày giao"
            value={receivedData.deliveryDate}
            onChange={(value) => onChangeDate(value, "deliveryDate")}
            disabled={
              receivedData?.status === "PACKING" ||
              receivedData?.status === "DONE" ||
              receivedData?.flagError ||
              isView
                ? true
                : false
            }
          />
        </CCol>
      </CRow>
      <CRow className="mt-15">
        <CCol xs={3}>
          {receivedData?.receivedLinkDeliveries?.length > 0 ? (
            <div class="tooltip1">
              <div>
                <AutoSuggest
                  options={[]}
                  label="Phếu giao liên kết"
                  disabled={true}
                  value={receivedLinkDeliveries}
                />
              </div>
              <span class="tooltiptext1">
                {receivedLinkDeliveries?.map((item) => (
                  <p>{item}</p>
                ))}
              </span>
            </div>
          ) : (
            // <Tooltip title={receivedLinkDeliveries}>
            //     <div>
            //         <AutoSuggest
            //             options={[]}
            //             label="Phếu giao liên kết"
            //             disabled={true}
            //             value={receivedLinkDeliveries}
            //         />
            //     </div>
            // </Tooltip>
            <AutoSuggest
              options={[]}
              label="Hợp đồng"
              disabled={true}
              value={receivedData?.contract}
            />
          )}
        </CCol>
        {receivedData?.productType == "special_product" && (
          <CCol xs={3}>
            <InputField
              label="Số phòng"
              value={receivedData?.numberRoom}
              onChange={onChangeReceivedData}
              name="numberRoom"
              disabled={checkDisableRoomNumber()}
            />
          </CCol>
        )}
        {receivedData?.status == "DONE" ? (
          " "
        ) : receivedData?.productType == "ordinary_product" ? (
          <CCol>
            <InputField
              name="referenceCode"
              label="Mã đối chiếu"
              //disabled={true}
              value={receivedData?.referenceCode}
              onChange={onChangeReceivedData}
            />
          </CCol>
        ) : (
          ""
        )}
        {/* {receivedData?.productType == "ordinary_product" ? (
            <CCol>
              <InputField
                name="referenceCode"
                label="Mã đối chiếu"
                //disabled={true}
                value={receivedData?.referenceCode}
                onChange={onChangeReceivedData}
              />
            </CCol>
          ) : (
            ""
          )} */}

        <CCol>
          <AutoSuggest
            label={"Xe"}
            name={"truck"}
            value={truck}
            onChange={onChangeTruck}
            onInputChange={onChangeTruck}
            options={trucks}
            disabled={
              receivedData?.status === "WAITING_RANDOM_CHECK" ||
              receivedData?.status === "WASHING" ||
              receivedData?.status === "PACKING" ||
              receivedData?.status === "DONE"
                ? true
                : false
            }
          />
        </CCol>
        <CCol>
          <AutoSuggest
            label={"Tài xế"}
            name={"driver"}
            value={driver}
            onChange={onChangeDriver}
            onInputChange={onChangeDriver}
            options={drivers}
            disabled={
              receivedData?.status === "WAITING_RANDOM_CHECK" ||
              receivedData?.status === "WASHING" ||
              receivedData?.status === "PACKING" ||
              receivedData?.status === "DONE"
                ? true
                : false
            }
          />
        </CCol>
      </CRow>

      <CRow className="mt-15">
        {receivedData?.status == "DONE" ? (
          " "
        ) : receivedData?.productType == "special_product" ? (
          <CCol xs={3}>
            <InputField
              name="referenceCode"
              label="Mã đối chiếu"
              //disabled={true}
              value={receivedData?.referenceCode}
              onChange={onChangeReceivedData}
            />
          </CCol>
        ) : (
          ""
        )}

        <CCol>
          <InputField
            name="note"
            label="Ghi chú"
            onChange={onChangeReceivedData}
            value={receivedData.note}
            disabled={
              receivedData?.status === "PACKING" ||
              receivedData?.status === "DONE" ||
              receivedData?.flagError ||
              isView
                ? true
                : false
            }
          />
        </CCol>
      </CRow>

      {receivedData?.status !== "WAITING" && (
        <CRow style={{ marginTop: 20 }}>
          <CCol>
            <CRow>
              <CCol xs={3}>
                <InputField
                  label="Trọng lượng(kg)"
                  value={totalWeight}
                  InputProps={{
                    readOnly: true,
                  }}
                />
              </CCol>
              {receivedData.status === "STAFF_RECEIVED" &&
                !receivedData.flagError &&
                !isView && (
                  <CCol xs={1}>
                    <AddCircleOutlineIcon
                      color="info"
                      style={{ marginTop: 10, cursor: "pointer" }}
                      onClick={() => {
                        var temp = [...weightTime];
                        temp.push({
                          id: uuid(),
                          value: 0,
                        });
                        console.log("temp", temp);
                        setWeightTime(temp);
                      }}
                    />
                  </CCol>
                )}
              <CCol>
                <div style={{ display: "flex", flexWrap: "wrap" }}>
                  {weightTime.map((item, index) => (
                    <div style={{ position: "relative" }}>
                      <InputField
                        width={"w-22"}
                        style={{
                          marginBottom: 10,
                          marginRight: 10,
                          width: 100,
                        }}
                        label={"Cân lần " + (index + 1)}
                        value={item.value}
                        onChange={(e) => changeWeightTime(e, item.id)}
                        type="number"
                        disabled={
                          receivedData.status !== "STAFF_RECEIVED" ||
                          receivedData?.flagError
                            ? true
                            : false
                        }
                      />
                      {receivedData.status === "STAFF_RECEIVED" &&
                        !receivedData.flagError &&
                        !isView && (
                          <div
                            onClick={(e) => onRemoveWeight(e, item)}
                            style={{
                              borderRadius: "50%",
                              border: "1px solid #D32F2F",
                              width: "20px",
                              height: "20px",
                              position: "absolute",
                              top: -2,
                              right: 7,
                              background: "white",
                              cursor: "pointer",
                            }}
                          >
                            <div
                              style={{
                                width: "100%",
                                display: "flex",
                                height: "20px",
                              }}
                            >
                              <ClearIcon
                                color="error"
                                sx={{ fontSize: "10px" }}
                              />
                            </div>
                          </div>
                        )}
                    </div>
                    // <span className='rounded-pill-div weight' style={{marginRight: 3}}>{item}</span>
                  ))}
                </div>
              </CCol>
            </CRow>
          </CCol>
        </CRow>
      )}

      <div className="flex justify-between my-2">
        <CLabel style={{ marginTop: 10 }} className="title">
          Danh sách mặt hàng
        </CLabel>
        {receivedData?.status === "WAITING" &&
          receivedData?.receivedLinkDeliveries.length === 0 &&
          !receivedData?.flagError &&
          !isView && (
            <NormalButton
              label="Chọn mặt hàng"
              size="small"
              sx={{ height: "35px", marginTop: "6px" }}
              onClick={onOpenProductPopup}
            />
          )}
        {console.log(
          receivedData?.receivedLinkDeliveries,
          "21111111111111111111111"
        )}
        {receivedData?.flagError &&
        (receivedData?.status === "WAITING_RANDOM_CHECK" ||
          receivedData?.status === "STAFF_RECEIVED" ||
          receivedData?.status === "WASHING" ||
          receivedData?.status === "WAITING") ? (
          receivedData?.receivedLinkDeliveries.length === 0 ? (
            <NormalButton
              label="Chọn mặt hàng"
              size="small"
              sx={{ height: "35px", marginTop: "6px" }}
              onClick={onOpenProductPopup}
            />
          ) : receivedData?.receivedLinkDeliveries.length > 0 ? (
            <NormalButton
              label="Chọn mặt hàng từ phiếu giao liên kết"
              size="small"
              sx={{ height: "35px", marginTop: "6px" }}
              onClick={onOpenLinkTicketProductPopup}
            />
          ) : (
            ""
          )
        ) : (
          ""
        )}
        {receivedData?.status === "WAITING" &&
          receivedData?.receivedLinkDeliveries.length > 0 &&
          !receivedData?.flagError &&
          !isView && (
            <NormalButton
              label="Chọn mặt hàng từ phiếu giao liên kết"
              size="small"
              sx={{ height: "35px", marginTop: "6px" }}
              onClick={onOpenLinkTicketProductPopup}
            />
          )}
      </div>

      <OrderSheetRecevied
        receivedData={receivedData}
        productList={productList}
        setProductList={setProductList}
        productListOptions={productListOptions}
        isReceivedReceiptError={isReceivedReceiptError}
        laundryFormOptions={laundryForms}
        isBagNumberError={isBagNumberError}
        isView={isView}
      />

      {isOpenProductListPopup && (
        <ProductListPopup
          isOpen={isOpenProductListPopup}
          handleClosePopup={onOpenProductPopup}
          productType={receivedData?.productType}
          existProductList={productList}
          onChangeProductList={onChangeProductList}
          producItemFromContract={prodcutItemFromContract}
          contractId={receivedData.contract?.value}
          // productType={receivedData?.productTypeValue}
          // existProductList={props.productList}
        />
      )}

      {isOpenLinkTicketProductPopup && (
        <DeliveryReceiptProductListPopup
          isOpen={isOpenLinkTicketProductPopup}
          handleClosePopup={onOpenLinkTicketProductPopup}
          existData={productList}
          // linkTicketProductList={linkTicketProductList}
          onGetProductListFromPopup={onGetProductListFromPopup}
          deliveryReceivedIds={receivedData.deliveryIds}
          receivedData={receivedData}
        />
      )}

      {receivedData?.status === "PACKING" || receivedData?.status === "DONE" ? (
        <>
          <div className="flex justify-between my-2">
            <CLabel style={{ marginTop: 10 }} className="title">
              Danh sách phiếu giao
            </CLabel>
          </div>

          <TableContainer
            mt={4}
            style={{ display: "flex", justifyContent: "flex-start" }}
          >
            <Table
              className={classesTable.table}
              aria-label="simple table"
              style={{
                border: "1px solid rgba(224, 224, 224, 1)",
                width: "50%",
              }}
            >
              <TableHead>
                <TableRow>
                  <StyledTableCell
                    size="small"
                    align="center"
                    style={{ color: "rgb(61,180,118)", fontWeight: "bold" }}
                  >
                    Mã phiếu
                  </StyledTableCell>
                  <StyledTableCell
                    size="small"
                    align="center"
                    style={{ color: "rgb(61,180,118)", fontWeight: "bold" }}
                  >
                    Trạng thái
                  </StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {deliveryLinks.map((item) => (
                  <StyledTableRow key={item?.code}>
                    <StyledTableCell size="small" align="left">
                      <Link
                        className="link-code"
                        component="button"
                        variant="body2"
                        onClick={(e) =>
                          onOpenAndCloseDeliveryPopup(item?.deliveryId)
                        }
                      >
                        {item?.code}
                      </Link>
                    </StyledTableCell>
                    <StyledTableCell size="small" align="center">
                      {item?.status}
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      ) : (
        ""
      )}

      <DeliveryPopup
        openDetail={isOpenDeliveryPopup}
        selectId={deliveryId}
        title={"Chi tiết phiếu giao"}
        handleClickOpenDetail={onOpenAndCloseDeliveryPopup}
      />
    </div>
  );
}
